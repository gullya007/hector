import React, { createContext, useContext, useState, ReactNode } from 'react';
import { User, Wallet, Withdrawal, Screen, WithdrawalMethod } from '../types';
import { DAILY_AD_COUNT, AD_REWARD, MIN_WITHDRAWAL_AMOUNT } from '../constants';

interface AppContextType {
  isLoggedIn: boolean;
  user: User | null;
  wallet: Wallet;
  adsWatchedToday: number;
  adsAvailable: boolean;
  withdrawals: Withdrawal[];
  currentScreen: Screen;
  login: () => void;
  logout: () => void;
  completeAd: () => void;
  requestWithdrawal: (amount: number, method: WithdrawalMethod) => boolean;
  setCurrentScreen: (screen: Screen) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const initialUser: User = {
    id: 'usr_123',
    name: 'Alex Doe',
    email: 'alex.doe@example.com',
    avatarUrl: `https://picsum.photos/seed/alex/100/100`,
    referralCode: 'ALEXD45',
    region: 'Orissa',
};

const initialWallet: Wallet = {
    balance: 125.50,
    pendingBalance: 2.50,
    totalEarned: 540.00,
};

const initialWithdrawals: Withdrawal[] = [
    { id: 'wd_001', amount: 150, method: 'UPI', status: 'Paid', date: '2023-10-15' },
    { id: 'wd_002', amount: 100, method: 'Bank Transfer', status: 'Paid', date: '2023-09-28' },
    { id: 'wd_003', amount: 200, method: 'PayPal', status: 'Paid', date: '2023-09-10' },
];

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [wallet, setWallet] = useState<Wallet>(initialWallet);
  const [adsWatchedToday, setAdsWatchedToday] = useState(2);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>(initialWithdrawals);
  const [currentScreen, setCurrentScreen] = useState<Screen>('dashboard');

  const adsAvailable = adsWatchedToday < DAILY_AD_COUNT;

  const login = () => {
    setUser(initialUser);
    setIsLoggedIn(true);
    setCurrentScreen('dashboard');
  };

  const logout = () => {
    setIsLoggedIn(false);
    setUser(null);
  };

  const completeAd = () => {
    if (adsAvailable) {
      setAdsWatchedToday(prev => prev + 1);
      setWallet(prev => ({
        ...prev,
        balance: prev.balance + AD_REWARD,
        totalEarned: prev.totalEarned + AD_REWARD,
      }));
    }
  };

  const requestWithdrawal = (amount: number, method: WithdrawalMethod): boolean => {
    if (wallet.balance >= amount && amount >= MIN_WITHDRAWAL_AMOUNT) {
      setWallet(prev => ({ ...prev, balance: prev.balance - amount }));
      const newWithdrawal: Withdrawal = {
        id: `wd_${Date.now()}`,
        amount,
        method,
        status: 'Requested',
        date: new Date().toISOString().split('T')[0],
      };
      setWithdrawals(prev => [newWithdrawal, ...prev]);
      return true;
    }
    return false;
  };

  const value = {
    isLoggedIn,
    user,
    wallet,
    adsWatchedToday,
    adsAvailable,
    withdrawals,
    currentScreen,
    login,
    logout,
    completeAd,
    requestWithdrawal,
    setCurrentScreen,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
