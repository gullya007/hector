export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  referralCode: string;
  region: string;
}

export interface Wallet {
  balance: number;
  pendingBalance: number;
  totalEarned: number;
}

export interface Ad {
  id: string;
  duration: number; 
  reward: number;
}

export type WithdrawalMethod = 'UPI' | 'PayPal' | 'Bank Transfer';

export interface Withdrawal {
  id: string;
  amount: number;
  method: WithdrawalMethod;
  status: 'Requested' | 'Processing' | 'Paid' | 'Rejected';
  date: string;
}

export type Screen = 'dashboard' | 'wallet' | 'profile' | 'ad-watch';
