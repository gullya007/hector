import React from 'react';
import { AppProvider, useAppContext } from './contexts/AppContext';
import LoginScreen from './screens/LoginScreen';
import DashboardScreen from './screens/DashboardScreen';
import WalletScreen from './screens/WalletScreen';
import ProfileScreen from './screens/ProfileScreen';
import AdWatchScreen from './screens/AdWatchScreen';
import Header from './components/Header';
import BottomNav from './components/BottomNav';

const AppContent: React.FC = () => {
    const { isLoggedIn, currentScreen } = useAppContext();

    if (!isLoggedIn) {
        return <LoginScreen />;
    }
    
    // This wrapper simulates a mobile phone screen
    return (
        <div className="w-full max-w-md mx-auto h-screen bg-gray-50 flex flex-col font-sans shadow-2xl">
            {currentScreen !== 'ad-watch' && <Header />}
            <main className="flex-grow overflow-y-auto">
                {currentScreen === 'dashboard' && <DashboardScreen />}
                {currentScreen === 'wallet' && <WalletScreen />}
                {currentScreen === 'profile' && <ProfileScreen />}
                {currentScreen === 'ad-watch' && <AdWatchScreen />}
            </main>
            {currentScreen !== 'ad-watch' && <BottomNav />}
        </div>
    );
};

const App: React.FC = () => {
    return (
        <AppProvider>
            <AppContent />
        </AppProvider>
    );
};

export default App;
