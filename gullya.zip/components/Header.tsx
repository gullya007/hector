import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { BellIcon, HectorsLogo } from './Icons';

const Header: React.FC = () => {
    const { wallet } = useAppContext();

    return (
        <header className="bg-white shadow-md p-4 flex justify-between items-center sticky top-0 z-10">
            <HectorsLogo className="text-sm md:text-base"/>
            <div className="flex items-center space-x-4">
                <div className="text-right">
                    <div className="text-sm font-semibold text-hector-blue">Balance</div>
                    <div className="text-lg font-bold text-green-600">₹{wallet.balance.toFixed(2)}</div>
                </div>
                <button className="text-gray-500 hover:text-hector-orange relative">
                    <BellIcon className="h-7 w-7" />
                    <span className="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full border-2 border-white"></span>
                </button>
            </div>
        </header>
    );
};

export default Header;
