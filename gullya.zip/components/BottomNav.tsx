import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { HomeIcon, WalletIcon, UserIcon } from './Icons';
import { Screen } from '../types';

interface NavItemProps {
  screen: Screen;
  label: string;
  icon: React.ReactNode;
}

const BottomNav: React.FC = () => {
  const { currentScreen, setCurrentScreen } = useAppContext();

  const NavItem: React.FC<NavItemProps> = ({ screen, label, icon }) => {
    const isActive = currentScreen === screen;
    const colorClass = isActive ? 'text-hector-orange' : 'text-gray-400';
    return (
      <button
        onClick={() => setCurrentScreen(screen)}
        className={`flex flex-col items-center justify-center space-y-1 w-full focus:outline-none transition-colors duration-200 ${colorClass} hover:text-hector-orange`}
      >
        {icon}
        <span className={`text-xs font-medium`}>{label}</span>
      </button>
    );
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200 flex justify-around p-2 z-10">
      <NavItem screen="dashboard" label="Home" icon={<HomeIcon className="h-6 w-6" />} />
      <NavItem screen="wallet" label="Wallet" icon={<WalletIcon className="h-6 w-6" />} />
      <NavItem screen="profile" label="Profile" icon={<UserIcon className="h-6 w-6" />} />
    </nav>
  );
};

export default BottomNav;
