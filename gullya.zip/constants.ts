export const DAILY_AD_COUNT = 9;
export const AD_REWARD = 250; // ₹250
export const AD_DURATION_SECONDS = 15;
export const MIN_WITHDRAWAL_AMOUNT = 100;
