import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { MIN_WITHDRAWAL_AMOUNT } from '../constants';
import { WithdrawalMethod } from '../types';

const WalletScreen: React.FC = () => {
  const { wallet, withdrawals, requestWithdrawal } = useAppContext();
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<WithdrawalMethod>('UPI');
  const [message, setMessage] = useState('');

  const handleWithdraw = () => {
    const numAmount = parseFloat(amount);
    if (!isNaN(numAmount)) {
      const success = requestWithdrawal(numAmount, method);
      if (success) {
        setMessage('Withdrawal request submitted!');
        setAmount('');
      } else {
        setMessage(`Failed. Ensure amount is >= ₹${MIN_WITHDRAWAL_AMOUNT} and you have enough balance.`);
      }
    } else {
        setMessage('Please enter a valid amount.');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Paid': return 'text-green-500';
      case 'Processing': return 'text-yellow-500';
      case 'Requested': return 'text-blue-500';
      case 'Rejected': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  return (
    <div className="p-4 space-y-6 bg-gray-50 pb-20">
      {/* Balance Summary Card */}
      <div className="bg-hector-blue text-white rounded-2xl shadow-lg p-6">
        <p className="text-lg opacity-80">Current Balance</p>
        <p className="text-5xl font-extrabold my-2">₹{wallet.balance.toFixed(2)}</p>
        <div className="flex justify-between mt-4 text-sm">
          <div>
            <p className="opacity-70">Pending</p>
            <p className="font-semibold">₹{wallet.pendingBalance.toFixed(2)}</p>
          </div>
          <div>
            <p className="opacity-70">Total Earned</p>
            <p className="font-semibold">₹{wallet.totalEarned.toFixed(2)}</p>
          </div>
        </div>
      </div>
      
      {/* Withdrawal Form Card */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="font-bold text-hector-blue mb-4 text-lg">Withdraw Funds</h3>
        <div className="space-y-4">
          <div>
            <label htmlFor="amount" className="text-sm font-medium text-gray-600 block mb-1">Amount (Min. ₹{MIN_WITHDRAWAL_AMOUNT})</label>
            <input 
                id="amount" 
                type="number" 
                value={amount} 
                onChange={e => setAmount(e.target.value)}
                placeholder="e.g., 150"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-hector-orange focus:border-hector-orange" 
            />
          </div>
          <div>
            <label htmlFor="method" className="text-sm font-medium text-gray-600 block mb-1">Method</label>
            <select 
                id="method" 
                value={method} 
                onChange={e => setMethod(e.target.value as WithdrawalMethod)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-hector-orange focus:border-hector-orange bg-white"
            >
              <option>UPI</option>
              <option>PayPal</option>
              <option>Bank Transfer</option>
            </select>
          </div>
          <button onClick={handleWithdraw} className="w-full bg-hector-orange text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition">
            Request Withdrawal
          </button>
          {message && <p className="text-sm text-center text-gray-600 mt-2">{message}</p>}
        </div>
      </div>

      {/* Withdrawal History */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="font-bold text-hector-blue mb-4 text-lg">Transaction History</h3>
        <ul className="space-y-4">
          {withdrawals.map(w => (
            <li key={w.id} className="flex justify-between items-center">
              <div>
                <p className="font-semibold text-gray-800">{w.method}</p>
                <p className="text-sm text-gray-500">{w.date}</p>
              </div>
              <div className="text-right">
                <p className="font-bold text-gray-800">₹{w.amount.toFixed(2)}</p>
                <p className={`text-sm font-semibold ${getStatusColor(w.status)}`}>{w.status}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default WalletScreen;
