import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { HectorsLogo } from '../components/Icons';

const LoginScreen: React.FC = () => {
  const { login } = useAppContext();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    login();
  };

  return (
    <div className="min-h-screen bg-hector-blue flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-sm">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex justify-center mb-6">
              <HectorsLogo />
          </div>
          <h2 className="text-center text-2xl font-bold text-gray-700 mb-2">Welcome Back!</h2>
          <p className="text-center text-gray-500 mb-8">Login to continue earning.</p>
          
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label htmlFor="email" className="text-sm font-medium text-gray-600 block mb-2">Email or Phone</label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-hector-orange focus:border-hector-orange transition"
              />
            </div>
            <div>
              <label htmlFor="password" className="text-sm font-medium text-gray-600 block mb-2">Password</label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-hector-orange focus:border-hector-orange transition"
              />
            </div>
            <button
              type="submit"
              className="w-full bg-hector-orange text-white font-bold py-3 rounded-lg hover:bg-orange-600 transition-transform transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-hector-orange"
            >
              Login
            </button>
          </form>
          <div className="text-center mt-6">
            <a href="#" className="text-sm text-hector-orange hover:underline">Forgot Password?</a>
          </div>
        </div>
        <p className="text-center text-white text-sm mt-6">
          Don't have an account? <a href="#" className="font-bold hover:underline">Sign Up</a>
        </p>
      </div>
    </div>
  );
};

export default LoginScreen;
