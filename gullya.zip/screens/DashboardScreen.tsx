import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { DAILY_AD_COUNT } from '../constants';

const DashboardScreen: React.FC = () => {
    const { adsWatchedToday, adsAvailable, setCurrentScreen } = useAppContext();
    const adsRemaining = DAILY_AD_COUNT - adsWatchedToday;

    const progressPercentage = (adsWatchedToday / DAILY_AD_COUNT) * 100;

    return (
        <div className="p-4 space-y-6 bg-gray-50 pb-20">
            {/* Ad Watching CTA Card */}
            <div className="bg-white rounded-2xl shadow-lg p-6 text-center transform hover:scale-[1.02] transition-transform duration-300">
                <h2 className="text-lg font-bold text-hector-blue">Today's Ads</h2>
                <p className="text-4xl font-extrabold text-hector-orange my-3">
                    {adsRemaining}
                    <span className="text-2xl text-gray-500">/{DAILY_AD_COUNT}</span>
                </p>
                <p className="text-gray-500 mb-4">Available to watch</p>

                {/* Progress Bar */}
                <div className="w-full bg-gray-200 rounded-full h-2.5 mb-6">
                    <div className="bg-hector-orange h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
                </div>

                <button
                    onClick={() => adsAvailable && setCurrentScreen('ad-watch')}
                    disabled={!adsAvailable}
                    className="w-full bg-hector-orange text-white font-bold py-4 rounded-lg text-lg
                               hover:bg-orange-600 transition-all duration-300 transform hover:scale-105
                               disabled:bg-gray-400 disabled:cursor-not-allowed disabled:transform-none"
                >
                    {adsAvailable ? 'Watch Ads' : 'Come back tomorrow!'}
                </button>
            </div>

            {/* Members Count Card */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="font-bold text-hector-blue mb-3 text-center">Community Growth</h3>
                <div className="flex justify-around text-center">
                    <div>
                        <p className="text-2xl font-bold text-gray-800">12,345</p>
                        <p className="text-sm text-gray-500">Global Members</p>
                    </div>
                    <div className="border-l border-gray-200"></div>
                    <div>
                        <p className="text-2xl font-bold text-gray-800">1,234</p>
                        <p className="text-sm text-gray-500">Orissa Members</p>
                    </div>
                </div>
            </div>

            {/* Invite Friends Card */}
            <div className="bg-hector-blue text-white rounded-2xl shadow-lg p-6 text-center">
                <h3 className="text-xl font-bold mb-2">Earn More!</h3>
                <p className="mb-4">Invite your friends and earn a bonus for each successful referral.</p>
                <button className="bg-hector-orange font-bold py-3 px-8 rounded-lg hover:bg-orange-600 transition-transform transform hover:scale-105">
                    Invite Friends
                </button>
            </div>
        </div>
    );
};

export default DashboardScreen;
