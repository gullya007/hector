import React, { useState, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { AD_DURATION_SECONDS, AD_REWARD } from '../constants';

const AdWatchScreen: React.FC = () => {
  const { completeAd, setCurrentScreen } = useAppContext();
  const [secondsLeft, setSecondsLeft] = useState(AD_DURATION_SECONDS);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    if (secondsLeft <= 0) {
      setIsComplete(true);
      return;
    }

    const timer = setInterval(() => {
      setSecondsLeft(secondsLeft - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [secondsLeft]);

  const handleClaimReward = () => {
    completeAd();
    setCurrentScreen('dashboard');
  };

  const progressPercentage = ((AD_DURATION_SECONDS - secondsLeft) / AD_DURATION_SECONDS) * 100;

  return (
    <div className="h-full flex flex-col bg-black text-white p-4">
      <div className="flex-grow flex flex-col items-center justify-center">
        {/* Placeholder for video ad */}
        <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center mb-4">
          <p className="text-gray-400">Advertisement playing...</p>
        </div>

        <div className="w-full text-center">
          {!isComplete ? (
            <>
              <p className="text-lg mb-2">Please watch the ad to earn your reward.</p>
              <p className="text-5xl font-bold font-mono text-hector-orange">{secondsLeft}</p>
              <p className="text-gray-400">seconds remaining</p>
            </>
          ) : (
            <div className="animate-fade-in">
              <h2 className="text-2xl font-bold text-green-400 mb-4">Ad complete!</h2>
              <button
                onClick={handleClaimReward}
                className="bg-green-500 text-white font-bold py-4 px-10 text-xl rounded-lg
                           hover:bg-green-600 transition transform hover:scale-110"
              >
                Claim ₹{AD_REWARD.toFixed(2)}
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="w-full">
        <div className="w-full bg-gray-700 rounded-full h-2">
          <div
            className="bg-hector-orange h-2 rounded-full transition-all duration-1000 linear"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};

export default AdWatchScreen;
