import React from 'react';
import { useAppContext } from '../contexts/AppContext';

// A simple toggle switch component defined locally
const ToggleSwitch: React.FC<{ label: string; enabled: boolean; onToggle: () => void; }> = ({ label, enabled, onToggle }) => (
    <div className="flex items-center justify-between">
        <span className="text-gray-700">{label}</span>
        <button
            onClick={onToggle}
            className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${enabled ? 'bg-hector-orange' : 'bg-gray-300'}`}
        >
            <span
                className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${enabled ? 'translate-x-6' : 'translate-x-1'}`}
            />
        </button>
    </div>
);

const ProfileScreen: React.FC = () => {
    const { user, logout } = useAppContext();
    const [notifications, setNotifications] = React.useState(true);
    const [adCategories, setAdCategories] = React.useState(false);

    if (!user) {
        return null;
    }

    return (
        <div className="p-4 space-y-6 bg-gray-50 pb-20">
            {/* User Info Card */}
            <div className="flex flex-col items-center bg-white rounded-2xl shadow-lg p-6">
                <img src={user.avatarUrl} alt="User Avatar" className="w-24 h-24 rounded-full border-4 border-hector-orange mb-4" />
                <h2 className="text-2xl font-bold text-hector-blue">{user.name}</h2>
                <p className="text-gray-500">{user.email}</p>
                <p className="text-sm text-gray-500 mt-1">Region: {user.region}</p>
                <div className="mt-4 bg-orange-100 text-hector-orange font-semibold px-4 py-2 rounded-lg">
                    Referral Code: <span className="font-bold">{user.referralCode}</span>
                </div>
            </div>

            {/* Profile Actions */}
            <div className="bg-white rounded-2xl shadow-lg p-6 space-y-4">
                <button className="w-full text-left text-gray-700 font-semibold p-2 rounded hover:bg-gray-100">
                    Edit Profile
                </button>
                <button className="w-full text-left text-gray-700 font-semibold p-2 rounded hover:bg-gray-100">
                    Change Password
                </button>
            </div>

            {/* Preferences */}
            <div className="bg-white rounded-2xl shadow-lg p-6 space-y-4">
                <h3 className="font-bold text-hector-blue mb-2 text-lg">Preferences</h3>
                <ToggleSwitch label="Push Notifications" enabled={notifications} onToggle={() => setNotifications(!notifications)} />
                <ToggleSwitch label="Tailored Ad Categories" enabled={adCategories} onToggle={() => setAdCategories(!adCategories)} />
                <div className="flex justify-between items-center pt-2">
                    <span className="text-gray-700">Language</span>
                    <span className="font-semibold text-hector-blue">English ▸</span>
                </div>
            </div>

            {/* Logout Button */}
            <div className="pt-4">
                <button
                    onClick={logout}
                    className="w-full bg-red-500 text-white font-bold py-3 rounded-lg hover:bg-red-600 transition"
                >
                    Logout
                </button>
            </div>
        </div>
    );
};

export default ProfileScreen;
